﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Emit;

namespace Erasmus.Data
{
    public class GamesNav
    {
        [Key]
        [Column("games_id")]
        public int GamesId { get; set; }

        public string Address { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
    }
    public class Game
    {
        [Key]
        [Column("games_id")]
        public int GamesId { get; set; }

        public string Address { get; set; } = string.Empty;
        public string Saga { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Developer { get; set; } = string.Empty;
        public string Publisher { get; set; } = string.Empty;
        public string Engine { get; set; } = string.Empty;
        public string Composer { get; set; } = string.Empty;
        [Column("Release date")]
        public string ReleaseDate { get; set; } = string.Empty;
        public string Genre { get; set; } = string.Empty;
        [Column("Game modes")]
        public string GameModes { get; set; } = string.Empty;
        [Column("ESRB rating")]
        public string ESRBRating { get; set; } = string.Empty;
        public string Platforms { get; set; } = string.Empty;
        [Column("Previous game")]
        public string PreviousGame { get; set; } = string.Empty;
        [Column("Next game")]
        public string NextGame { get; set; } = string.Empty;
    }
    public class HomeGame
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }
        [Column("games_id")]
        public int GamesId { get; set; }
    }

    public class Content
    {
        [Key]
        public int Id { get; set; }
        [Column("games_id")]
        public int GamesId { get; set; }
        public string Headline { get; set; }
        public string Text { get; set; }
    }

    public class GamesNavData
    {
        [Key]
        [Column("id")]
        public int Id { get; set; }

        public string Address { get; set; } = string.Empty;
    }
    public class GameData
    {
        [Key]
        [Column(Order = 1)]
        public string Title { get; set; } = string.Empty;

        [Column(Order = 2)]
        public string Developer { get; set; } = string.Empty;

        [Column(Order = 3)]
        public string Publisher { get; set; } = string.Empty;

        [Column(Order = 4)]
        public string Engine { get; set; } = string.Empty;

        [Column(Order = 5)]
        public string Composer { get; set; } = string.Empty;

        [Column("Release date", Order = 6)]
        public string ReleaseDate { get; set; } = string.Empty;

        [Column(Order = 7)]
        public string Genre { get; set; } = string.Empty;

        [Column("Game modes", Order = 8)]
        public string GameModes { get; set; } = string.Empty;

        [Column("ESRB rating", Order = 9)]
        public string ESRBRating { get; set; } = string.Empty;

        [Column(Order = 10)]
        public string Platforms { get; set; } = string.Empty;

        [Column("Previous game", Order = 12)]
        public string PreviousGame { get; set; } = string.Empty;

        [Column("Next game", Order = 13)]
        public string NextGame { get; set; } = string.Empty;
    }



    public class ErasmusDbContext : DbContext
    {
        public ErasmusDbContext(DbContextOptions<ErasmusDbContext> options) : base(options)
        {
        }

        public DbSet<Game> Games { get; set; }
        public DbSet<HomeGame> HomeGames { get; set; }
        public DbSet<Content> Contents { get; set; }
        public DbSet<GamesNav> GamesNav { get; set; }
        public DbSet<GamesNavData> GamesNavData { get; set; }
        public DbSet<GameData> GamesData { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Konfiguracje mapowania encji i innych ustawień
            base.OnModelCreating(modelBuilder);
        }
    }
}

