using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Erasmus.Pages
{
    public class ArticlesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
