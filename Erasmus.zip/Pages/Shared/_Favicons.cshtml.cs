using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Erasmus.Pages.Shared
{
    public class _FaviconsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
