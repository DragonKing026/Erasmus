using Erasmus.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

// Connection string - zast�p nazw� u�ytkownika, has�em i nazw� bazy danych, je�li s� inne
var connectionString = "Server=localhost;Port=3306;Database=erasmus;User Id=website;Password=Qwerty123!";

builder.Services.AddDbContext<ErasmusDbContext>(options =>
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

var app = builder.Build();

// Konfiguruj pipeline HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Use(async (context, next) =>
{
    await next();

    if (context.Response.StatusCode == 404 && !context.Request.Path.StartsWithSegments("/Error"))
    {
        context.Request.Path = "/Error";
        await next();
    }
});
app.Map("/Error", errorApp =>
{
    errorApp.Run(async context =>
    {
        context.Response.StatusCode = 404;
        await context.Response.WriteAsync("Page not found. We apologize for the inconvenience.");
    });
});

app.Run();
