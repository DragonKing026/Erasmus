﻿"use strict";
let root = document.documentElement;
function mainTurnOnOff() {
    let mode = document.querySelector(".mode").getAttribute("data-mode");
    let text_white = document.querySelectorAll(".w3-text-white");
    let text_black = document.querySelectorAll(".w3-text-black");
    text_white.forEach(el => {
        el.classList.replace("w3-text-white", "w3-text-black");
    });
    text_black.forEach(el => {
        el.classList.replace("w3-text-black", "w3-text-white");
    });
    if (mode == "moon") {
        document.querySelector(".mode").src = "/images/index_img/sun.png";
        document.querySelector(".mode").setAttribute("data-mode", "sun");
        document.querySelector("body").style.backgroundImage = 'url("/images/index_img/wallpaper3.jpg")';
        document.querySelector("body").style.backgroundSize = "contain";
        root.style.setProperty("--main-color", "rgba(199, 193, 196, 0.57)");
        root.style.setProperty("--lines-color", "black");
        root.style.setProperty("--main-info-color", "#f44336");
    }
    else {
        document.querySelector(".mode").src = "/images/index_img/moon.png";
        document.querySelector(".mode").setAttribute("data-mode", "moon");
        document.querySelector("body").style.backgroundImage = 'url("/images/index_img/wallpaper2.jpg")';
        document.querySelector("body").style.backgroundSize = "cover";
        root.style.setProperty("--main-color", "rgba(36, 34, 35, 0.94)");
        root.style.setProperty("--lines-color", "white");
        root.style.setProperty("--main-info-color", "#1abc9c");
    }
};
function mainSizeChange() {
    let main_height = document.querySelector("div.main").offsetHeight;
    root.style.setProperty("--main-height", main_height + "px");
};
function homeImgPosition(el) {
    let id = el.id.substr(5);
    let img = document.querySelector("#home_tooltip_" + id);
    let position = (-1 * img.offsetHeight);
    root.style.setProperty("--home-img-position-bottom", position + "px");
}
function mainInformationHideShow() {
    let info = document.querySelector("#mainInformationAccordion");
    if (info.getAttribute("data-show") == "1") {
        info.classList.replace("w3-show", "w3-hide");
        info.setAttribute("data-show", 0);
    }
    else {
        info.classList.replace("w3-hide", "w3-show");
        info.setAttribute("data-show", 1);
    }
}